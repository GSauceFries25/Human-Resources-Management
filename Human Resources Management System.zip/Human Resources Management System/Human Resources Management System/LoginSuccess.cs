﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Human_Resources_Management_System
{
    public partial class LoginSuccessForm : Form
    {
        MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
        MySqlCommand cmd;
        MySqlDataAdapter adapt;
        public LoginSuccessForm()
        {
            InitializeComponent();
            DisplayData();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm frm1 = new LoginForm();
            frm1.ShowDialog();
        }

        private void LoginSuccessForm_Load(object sender, EventArgs e)
        {
  
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            // Checks if Username Exists
            MySqlCommand cmd1 = new MySqlCommand("SELECT * FROM loginform.userinfo WHERE Username = @UserName", con);
            cmd1.Parameters.AddWithValue("@UserName", txtUsername.Text);
            con.Open();
            bool userExists = false;
            using (var dr1 = cmd1.ExecuteReader())
                if (userExists = dr1.HasRows)
                    MessageBox.Show("Username not available!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            con.Close();
            if (!(userExists))
            {
                // Adds a User in the Database
                if (txtUsername.Text != "" && txtPassword.Text != "" && txtID.Text != "" && txtFName.Text != "" && txtLName.Text != "" && txtGender.Text != "" && txtBirthday.Text != "" && txtEmail.Text != "")
                {
                    cmd = new MySqlCommand("insert into loginform.userinfo(ID,Username,Password,FirstName,LastName,Gender,Birthday,Email) values(NULL,@name,@pass)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@id", txtID.Text);
                    cmd.Parameters.AddWithValue("@name", txtUsername.Text);
                    cmd.Parameters.AddWithValue("@pass", txtPassword.Text);
                    cmd.Parameters.AddWithValue("@FirstName", txtFName.Text);
                    cmd.Parameters.AddWithValue("@LastName", txtLName.Text);
                    cmd.Parameters.AddWithValue("@Gender", txtGender.Text);
                    cmd.Parameters.AddWithValue("@Birthday", txtBirthday.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record Successfully Added", "INSERT", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DisplayData();
                    ClearData();
                }
                else
                {
                    MessageBox.Show("Fill out all the information needed", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // para ma display ang Data Grid View  
        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new MySqlDataAdapter("select * from loginform.userinfo", con);
            adapt.Fill(dt);
            dataGridView.DataSource = dt;
            con.Close();
        }
        // Clears the Data  
        private void ClearData()
        {
            txtID.Text = "";
            txtUsername.Text = "";
            txtPassword.Text = "";
            txtFName.Text = "";
            txtLName.Text = "";
            txtGender.Text = "";
            txtBirthday.Text = "";
            txtEmail.Text = "";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text != "" && txtPassword.Text != "" && txtID.Text != "" && txtFName.Text != "" && txtLName.Text != "" && txtGender.Text != "" && txtBirthday.Text != "" && txtEmail.Text != "")
            {
                cmd = new MySqlCommand("update loginform.userinfo set Username=@name, Password=@pass, FirstName=@FirstName, LastName=@LastName, Gender=@Gender, Birthday=@Birthday, Email=@Email where ID=@id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", txtID.Text);
                cmd.Parameters.AddWithValue("@name", txtUsername.Text);
                cmd.Parameters.AddWithValue("@pass", txtPassword.Text);
                cmd.Parameters.AddWithValue("@FirstName", txtFName.Text);
                cmd.Parameters.AddWithValue("@LastName", txtLName.Text);
                cmd.Parameters.AddWithValue("@Gender", txtGender.Text);
                cmd.Parameters.AddWithValue("@Birthday", txtBirthday.Text);
                cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Successfully Updated", "UPDATE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Select the record you want to Update", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text != "" && txtPassword.Text != "" && txtID.Text != "" && txtFName.Text != "" && txtLName.Text != "" && txtGender.Text != "" && txtBirthday.Text != "" && txtEmail.Text != "")
            {
                cmd = new MySqlCommand("delete from loginform.userinfo where ID=@id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", txtID.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Successfully Deleted", "DELETE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Select the record you want to Delete", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtID.Text = dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtUsername.Text = dataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtPassword.Text = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtFName.Text = dataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtLName.Text = dataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtGender.Text = dataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
            txtBirthday.Text = dataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
            txtEmail.Text = dataGridView.Rows[e.RowIndex].Cells[7].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlCommand cmd1 = new MySqlCommand("SELECT * FROM accountinfo.userinfo WHERE Username = @UserName", con);
            cmd1.Parameters.AddWithValue("@UserName", txtUsername.Text);
            con.Open();
            bool userExists = false;
            using (var dr1 = cmd1.ExecuteReader())
                if (userExists = dr1.HasRows)
                    MessageBox.Show("Username not available!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            con.Close();
            if (!(userExists))
            {
                // mag add ng user sa Database
                if (txtUsername.Text != "" && txtPassword.Text != "")
                {
                    cmd = new MySqlCommand("insert into accountinfo.userinfo(ID,Username,Password, FirstName, LastName, Gender, Birthday, Email) values(NULL,@name,@pass)", con);
                    con.Open();
                    cmd.Parameters.AddWithValue("@id", txtID.Text);
                    cmd.Parameters.AddWithValue("@name", txtUsername.Text);
                    cmd.Parameters.AddWithValue("@pass", txtPassword.Text);
                    cmd.Parameters.AddWithValue("@FirstName", txtFName.Text);
                    cmd.Parameters.AddWithValue("@LastName", txtLName.Text);
                    cmd.Parameters.AddWithValue("@Gender", txtGender.Text);
                    cmd.Parameters.AddWithValue("@Birthday", txtBirthday.Text);
                    cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Record Successfully Added", "INSERT", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    DisplayData();
                    ClearData();
                }
                else
                {
                    MessageBox.Show("Fill out all the information needed", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void cboGender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
